import git
import re 
import sys
import signal
import pandas as pd
 
REPO_DIRECTION = "./skale-manager"

def control_c_pressed(signal, frame): #Function to handle the Ctrl+C
    print('Ctrl+C was pressed. Exiting the program.')
    sys.exit()

def extract(): #Function to extract the commits from the repository
    repository = git.Repo(REPO_DIRECTION)
    commits = []
    for commit in repository.iter_commits('develop'):
        commits.append(commit)
    return commits

def transform(commits): #Function to filter the commits
    list_commits = []
    words = ['password', 'secret', 'key', 'credential', 'access', 'private', 'secret']
    for commit in commits:
        for word in words:
            if re.search(word, commit.message, re.IGNORECASE): #Search the words in the commit message with regex
                list_commits.append([commit.hexsha, commit.message])
    return list_commits

def load(list_commits): #Function to print the commits and write them in a txt file
    for commit in list_commits:
        print('Commit: {} - {}'.format(commit[0], commit[1]))
    #create a csv file with the commits
    df = pd.DataFrame(list_commits, columns = ['Commit', 'Message'])
    df.to_csv('commits.csv', index=False)

    print('End of the program.') #program end
    sys.exit()

if __name__ == '__main__':
    signal.signal(signal.SIGINT, control_c_pressed)
    commits = extract() #ETL process
    list_commits = transform(commits)
    load(list_commits)


